<?php
//host name
$host = "localhost";
//user name
$username = "id16401478_root";
//database password
$password = "&flC)*gbE4OF2b8-";
//database name
$database ="id16401478_odhil";
$mysqli = new mysqli($host,$username,$password,$database) or die($mysqli->error);

?>