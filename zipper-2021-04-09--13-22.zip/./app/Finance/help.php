<html>
<head>
<title>UGUNJA</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

        <style>
li
{
    width: 100%;
    padding: 12px 20px;
    background-color: rgb(175, 179, 175);
    margin: 8px 0;
    box-sizing: border-box;
    border-radius: 25px 10px 25px 10px;
}

    p {
    text-align: center;
    color: rgb(235, 238, 235);
    background: black;
    font-size: 35px;
    border-radius: 25px;
}

h1 {
    text-align: center;
    color: rgb(52, 66, 52);
    border-radius: 25px;
    tab-size: 25px;
}

h2 {
    text-align: left;
    color: rgb(52, 66, 52);
    border-radius: 25px;
    tab-size: 15px;
}

button{
    font-size: 17px;
    text-align: center;
    color: rgb(182, 16, 16);
    border-radius: 25px;
    margin-left: 20px;
    background: rgb(243, 245, 244);

}

button:hover
{
    background: rgb(112, 114, 113);
}

fieldset
{
    border-radius: 25px;
    
    
}

div{
  
    width: 550px;
    height: 180px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 7px;
    background-color: rgb(231, 232, 235);
    border-style: solid;
    border-color: rgb(41, 37, 37);
    border-radius: 25px;
}

                </style>

</head>
<body>
    
<fieldset>
 
            


            <p>Popular Topics</p>
			<ul>
                        <li><a href="some.php">What if I have a question?</a></li>
                        <li><a href="some.php">Where can I get support?</a></li>
                        <li><a href="some.php">How long does it take to fix a problem?</a></li>
                        <li><a href="some.php">Who can help me out?</a></li>
                        <li><a href="some.php">Where are you located?</a></li>
                    
		 </ul>
        </fieldset>   
                              </div>
</body>
</html>